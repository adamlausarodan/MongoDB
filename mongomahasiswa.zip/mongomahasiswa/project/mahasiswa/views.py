from django.shortcuts import render, redirect, get_object_or_404
from .models import Mahasiswa
from mongoengine.errors import DoesNotExist  # Import for handling not found errors


def mahasiswa_list(request):
    mahasiswa = Mahasiswa.objects.all()  # Fetch all students from MongoDB
    return render(request, 'mahasiswa_list.html', {'mahasiswa': mahasiswa}) 

def tambah_mahasiswa(request):
    if request.method == 'POST':
        # Get the form data from POST request
        nama = request.POST.get('Nama')
        nim = request.POST.get('Nim')
        ttl = request.POST.get('Ttl')
        jenis_kelamin = request.POST.get('Jenis_Kelamin')
        no_telepon = request.POST.get('No_Telepon')

        # Create a new Mahasiswa instance and save it to MongoDB
        mahasiswa = Mahasiswa(
            Nama=nama,
            Nim=nim,
            Ttl=ttl,
            Jenis_Kelamin=jenis_kelamin,
            No_Telepon=no_telepon
        )
        mahasiswa.save()  # Save to MongoDB

        # Redirect to the mahasiswa list page after saving
        return redirect('mahasiswa_list')

    # If the request is GET, render the form
    return render(request, 'tambah_data.html')

def hapus_mahasiswa(request, mahasiswa_id):
    try:
        mahasiswa = Mahasiswa.objects.get(id=mahasiswa_id)  # Fetch the Mahasiswa object using MongoDB's query
        mahasiswa.delete()  # Delete the student from MongoDB
    except DoesNotExist:
        # Handle the case where the Mahasiswa doesn't exist
        return render(request, 'error.html', {'message': 'Mahasiswa tidak ditemukan.'})

    return redirect('mahasiswa_list')  # Redirect back to the student list after deletion

def edit_mahasiswa(request, mahasiswa_id):
    try:
        mahasiswa = Mahasiswa.objects.get(id=mahasiswa_id)  # Fetch the Mahasiswa object from MongoDB
    except DoesNotExist:
        # Handle the case where the Mahasiswa doesn't exist
        return render(request, 'error.html', {'message': 'Mahasiswa tidak ditemukan.'})

    if request.method == 'POST':
        # Update the Mahasiswa fields from the form data
        mahasiswa.Nama = request.POST.get('Nama')
        mahasiswa.Nim = request.POST.get('Nim')
        mahasiswa.Ttl = request.POST.get('Ttl')
        mahasiswa.Jenis_Kelamin = request.POST.get('Jenis_Kelamin')
        mahasiswa.No_Telepon = request.POST.get('No_Telepon')
        
        mahasiswa.save()  # Save the updated Mahasiswa document in MongoDB
        return redirect('mahasiswa_list')  # Redirect back to the list after saving

    return render(request, 'edit_data.html', {'mahasiswa': mahasiswa})  # Display form with the current data