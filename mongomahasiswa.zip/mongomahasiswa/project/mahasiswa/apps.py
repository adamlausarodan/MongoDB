from django.apps import AppConfig


class MahasiswaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mahasiswa'
