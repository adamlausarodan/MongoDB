from django.urls import path
from . import views

urlpatterns = [
    path('', views.mahasiswa_list, name='home'),
    path('mahasiswa/', views.mahasiswa_list, name='mahasiswa_list'),
    path('tambah/', views.tambah_mahasiswa, name='tambah_mahasiswa'),
    path('hapus/<str:mahasiswa_id>/', views.hapus_mahasiswa, name='hapus_mahasiswa'),  # URL for delete action
    path('edit/<str:mahasiswa_id>/', views.edit_mahasiswa, name='edit_mahasiswa'),  # Edit URL
]